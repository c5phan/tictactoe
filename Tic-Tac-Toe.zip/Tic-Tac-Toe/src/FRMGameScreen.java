
import java.awt.Color;
import java.util.*;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Cindy
 */
public class FRMGameScreen extends javax.swing.JFrame {

    /**
     * Creates new form FRMGameScreen
     */
    public String turn = "_X_";
    public int turnsleft = 9;
    public boolean singlePlayer = true;
    public FRMGameScreen() {
        initComponents();
        game.setVisible(false);
        resetButton.setVisible(false);
        modeButton.setVisible(false);
        if (singlePlayer == true){
            resetArray();
        }
    }
   
    // resets game back to default board
    public void resetGame(){
        showButtons();
        resetMoves();
        turnsleft = 9;
        turn = "_X_";
        instruct1.setText("Welcome to Tic-Tac-Toe!");
        instruct2.setText("Try to get 3 in a row. "
                + "Click any button to place your first move (Player X's Turn)!");
        resetButton.setVisible(false);
        modeButton.setVisible(false);
        if (singlePlayer == true){
            resetArray();
        }
    }
    
    // shows the play buttons
    public void showButtons(){
        buttonml.setVisible(true);
        buttonm.setVisible(true);
        buttonmr.setVisible(true);
        buttontl.setVisible(true);
        buttontm.setVisible(true);
        buttontr.setVisible(true);
        buttonbl.setVisible(true);
        buttonbm.setVisible(true);
        buttonbr.setVisible(true);
    }
    
    // resets the move labels to empty
    public void resetMoves(){
        movetl.setText("");
        movetm.setText("");
        movetr.setText("");
        moveml.setText("");
        movem.setText("");
        movemr.setText("");
        movebl.setText("");
        movebm.setText("");
        movebr.setText("");
        movetl.setForeground(Color.black);
        movetm.setForeground(Color.black);
        movetr.setForeground(Color.black);
        moveml.setForeground(Color.black);
        movem.setForeground(Color.black);
        movemr.setForeground(Color.black);
        movebl.setForeground(Color.black);
        movebm.setForeground(Color.black);
        movebr.setForeground(Color.black);
    }
    
    // checks if there is any 3 in a rows
    public void anyWins(){
        if ((movetr.getText().equals(movetl.getText())) && (movetl.getText().equals(movetm.getText()))){
            if (!(movetr.getText().equals(""))){
                String winner = getVal(movetr.getText());
                instruct1.setText("GAME OVER!");
                instruct2.setText("The winner is: " + winner);
                movetl.setForeground(Color.blue);
                movetm.setForeground(Color.blue);
                movetr.setForeground(Color.blue);
                hideButtons();
                resetButton.setVisible(true);
                modeButton.setVisible(true);
            }
        }
        else if ((movemr.getText().equals(moveml.getText())) && (moveml.getText().equals(movem.getText()))){
            if (!(movemr.getText().equals(""))){
                String winner = getVal(movemr.getText());
                instruct1.setText("GAME OVER!");
                instruct2.setText("The winner is: " + winner);
                movemr.setForeground(Color.blue);
                movem.setForeground(Color.blue);
                moveml.setForeground(Color.blue);
                hideButtons();
                resetButton.setVisible(true);
                modeButton.setVisible(true);
            }
        }
        else if ((movebr.getText().equals(movebl.getText())) && (movebl.getText().equals(movebm.getText()))){
            if (!(movebr.getText().equals(""))){
                String winner = getVal(movebr.getText());
                instruct1.setText("GAME OVER!");
                instruct2.setText("The winner is: " + winner);
                movebr.setForeground(Color.blue);
                movebm.setForeground(Color.blue);
                movebl.setForeground(Color.blue);
                hideButtons();
                resetButton.setVisible(true);
                modeButton.setVisible(true);
            }
        }
        else if ((movebr.getText().equals(movemr.getText())) && (movemr.getText().equals(movetr.getText()))){
            if (!(movetr.getText().equals(""))){
                String winner = getVal(movebr.getText());
                instruct1.setText("GAME OVER!");
                instruct2.setText("The winner is: " + winner);
                movebr.setForeground(Color.blue);
                movemr.setForeground(Color.blue);
                movetr.setForeground(Color.blue);
                hideButtons();
                resetButton.setVisible(true);
                modeButton.setVisible(true);
            }
        }
        else if ((movetm.getText().equals(movem.getText())) && (movem.getText().equals(movebm.getText()))){
            if (!(movetm.getText().equals(""))){
                String winner = getVal(movebm.getText());
                instruct1.setText("GAME OVER!");
                instruct2.setText("The winner is: " + winner);
                movetm.setForeground(Color.blue);
                movebm.setForeground(Color.blue);
                movem.setForeground(Color.blue);
                hideButtons();
                resetButton.setVisible(true);
                modeButton.setVisible(true);
            }
        }
        else if ((movetl.getText().equals(movebl.getText())) && (movebl.getText().equals(moveml.getText()))){
            if (!(movetl.getText().equals(""))){
                String winner = getVal(movebl.getText());
                instruct1.setText("GAME OVER!");
                instruct2.setText("The winner is: " + winner);
                movetl.setForeground(Color.blue);
                movebl.setForeground(Color.blue);
                moveml.setForeground(Color.blue);
                hideButtons();
                resetButton.setVisible(true);
                modeButton.setVisible(true);
            }
        }
        else if ((movetl.getText().equals(movem.getText())) && (movem.getText().equals(movebr.getText()))){
            if (!(movetl.getText().equals(""))){
                String winner = getVal(movem.getText());
                instruct1.setText("GAME OVER!");
                instruct2.setText("The winner is: " + winner);
                movetl.setForeground(Color.blue);
                movem.setForeground(Color.blue);
                movebr.setForeground(Color.blue);
                hideButtons();
                resetButton.setVisible(true);
                modeButton.setVisible(true);
            }
        }
        else if ((movetr.getText().equals(movem.getText())) && (movem.getText().equals(movebl.getText()))){
            if (!(movetr.getText().equals(""))){
                String winner = getVal(movem.getText());
                instruct1.setText("GAME OVER!");
                instruct2.setText("The winner is: " + winner);
                movetr.setForeground(Color.blue);
                movem.setForeground(Color.blue);
                movebl.setForeground(Color.blue);
                hideButtons();
                resetButton.setVisible(true);
                modeButton.setVisible(true);
            }
        }
        else if (turnsleft == 0){
            instruct2.setText("No one wins!");
            resetButton.setVisible(true);
            modeButton.setVisible(true);
        }
    }
    
    // checks for X or O occurence in a string
    public String getVal(String val){
        if (val.contains("X")){
            return "X";
        }
        else {
            return "O";
        }
    }
    
    // returns current turn
    public String getTurn(){
        return turn;
    }
    
    // sets current turn
    public void setTurn(){
        if (turnsleft == 1){
            turnsleft--;
            anyWins();
        }
        else if (getTurn().equals("_X_")){
            turn = "_O_";
            instruct2.setText("Player O's Turn!");
            turnsleft--;
        }
        else if (getTurn().equals("_O_")){
            turn = "_X_";
            instruct2.setText("Player X's Turn!");
            turnsleft--;
        }
    }
    
    // hides play buttons
    public void hideButtons(){
        buttonml.setVisible(false);
        buttonm.setVisible(false);
        buttonmr.setVisible(false);
        buttontl.setVisible(false);
        buttontm.setVisible(false);
        buttontr.setVisible(false);
        buttonbl.setVisible(false);
        buttonbm.setVisible(false);
        buttonbr.setVisible(false);   
    }
   
    // Functions for player vs AI
    public ArrayList<Integer> aiMoves = new ArrayList<>();
    public int aiChoice = 0;
    
    // places moves for AI based on random value
    public void playAI(){
        aiChoice = (aiMoves.get((int)(Math.random()*(aiMoves.size()-1))));
        if (aiChoice == 0){
            aiMoves.remove(findIndex(0));
            buttontl.setVisible(false);
            movetl.setText(getTurn());
            setTurn();
            anyWins();
        }
        else if (aiChoice == 1){
            aiMoves.remove(findIndex(1));
            buttontm.setVisible(false);
            movetm.setText(getTurn());
            setTurn();
            anyWins();
        }
        else if (aiChoice == 2){
            aiMoves.remove(findIndex(2));
            buttontr.setVisible(false);
            movetr.setText(getTurn());
            setTurn();
            anyWins();
        }
        else if (aiChoice == 3){
            aiMoves.remove(findIndex(3));
            buttonml.setVisible(false);
            moveml.setText(getTurn());
            setTurn();
            anyWins();  
        }
        else if (aiChoice == 4){
            aiMoves.remove(findIndex(4));
            buttonm.setVisible(false);
            movem.setText(getTurn());
            setTurn();
            anyWins();
        }
        else if (aiChoice == 5){
            aiMoves.remove(findIndex(5));
            buttonmr.setVisible(false);
            movemr.setText(getTurn());
            setTurn();
            anyWins();
        }
        else if (aiChoice == 6){
            aiMoves.remove(findIndex(6));
            buttonbl.setVisible(false);
            movebl.setText(getTurn());
            setTurn();
            anyWins();
        }
        else if (aiChoice == 7){
            aiMoves.remove(findIndex(7));
            buttonbm.setVisible(false);
            movebm.setText(getTurn());
            setTurn();
            anyWins();
        }
        else if (aiChoice == 8){
            aiMoves.remove(findIndex(8));
            buttonbr.setVisible(false);
            movebr.setText(getTurn());
            setTurn();
            anyWins();
        }
    }
    
    // finds the index of a value in an array
    public int findIndex(int num){
        int pos = 0;
        for (int i = 0; i < aiMoves.size(); i++){
            if (aiMoves.get(i).equals(num)){
                pos = i;
            }
        }
        return pos;
    }
    
    // resets the array to contain values 0-8
    public void resetArray(){
        aiMoves.clear();
        for (int i = 0; i < 9; i++){
            aiMoves.add(i);
        }
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        game = new javax.swing.JLayeredPane();
        titlepanel = new javax.swing.JPanel();
        title = new javax.swing.JLabel();
        gamefunctions = new javax.swing.JLayeredPane();
        selections = new javax.swing.JLayeredPane();
        topleft = new javax.swing.JPanel();
        movetl = new javax.swing.JLabel();
        buttontl = new javax.swing.JButton();
        topm = new javax.swing.JPanel();
        movetm = new javax.swing.JLabel();
        buttontm = new javax.swing.JButton();
        topright = new javax.swing.JPanel();
        movetr = new javax.swing.JLabel();
        buttontr = new javax.swing.JButton();
        midleft = new javax.swing.JPanel();
        moveml = new javax.swing.JLabel();
        buttonml = new javax.swing.JButton();
        mid = new javax.swing.JPanel();
        movem = new javax.swing.JLabel();
        buttonm = new javax.swing.JButton();
        midright = new javax.swing.JPanel();
        movemr = new javax.swing.JLabel();
        buttonmr = new javax.swing.JButton();
        botleft = new javax.swing.JPanel();
        movebl = new javax.swing.JLabel();
        buttonbl = new javax.swing.JButton();
        botmid = new javax.swing.JPanel();
        movebm = new javax.swing.JLabel();
        buttonbm = new javax.swing.JButton();
        botright1 = new javax.swing.JPanel();
        movebr = new javax.swing.JLabel();
        buttonbr = new javax.swing.JButton();
        board1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        instruct1 = new javax.swing.JLabel();
        instruct2 = new javax.swing.JLabel();
        resetButton = new javax.swing.JButton();
        modeButton = new javax.swing.JButton();
        menu = new javax.swing.JLayeredPane();
        menuTitle = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        modeAI = new javax.swing.JButton();
        mode2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new javax.swing.OverlayLayout(getContentPane()));

        game.setToolTipText("");

        title.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        title.setForeground(new java.awt.Color(153, 153, 255));
        title.setText("TIC-TAC-TOE");

        javax.swing.GroupLayout titlepanelLayout = new javax.swing.GroupLayout(titlepanel);
        titlepanel.setLayout(titlepanelLayout);
        titlepanelLayout.setHorizontalGroup(
            titlepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(titlepanelLayout.createSequentialGroup()
                .addGap(154, 154, 154)
                .addComponent(title)
                .addContainerGap(163, Short.MAX_VALUE))
        );
        titlepanelLayout.setVerticalGroup(
            titlepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, titlepanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(title)
                .addGap(407, 407, 407))
        );

        topleft.setOpaque(false);
        topleft.setLayout(new javax.swing.OverlayLayout(topleft));

        movetl.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        movetl.setRequestFocusEnabled(false);
        topleft.add(movetl);

        buttontl.setText("Top Left");
        buttontl.setToolTipText("");
        buttontl.setActionCommand("buttonTL");
        buttontl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                buttontlMousePressed(evt);
            }
        });
        topleft.add(buttontl);

        topm.setOpaque(false);
        topm.setLayout(new javax.swing.OverlayLayout(topm));

        movetm.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        topm.add(movetm);

        buttontm.setText("Top Mid");
        buttontm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                buttontmMousePressed(evt);
            }
        });
        topm.add(buttontm);

        topright.setOpaque(false);
        topright.setLayout(new javax.swing.OverlayLayout(topright));

        movetr.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        topright.add(movetr);

        buttontr.setText("Top Right");
        buttontr.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                buttontrMousePressed(evt);
            }
        });
        topright.add(buttontr);

        midleft.setOpaque(false);
        midleft.setLayout(new javax.swing.OverlayLayout(midleft));

        moveml.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        midleft.add(moveml);

        buttonml.setText("Mid Left");
        buttonml.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                buttonmlMousePressed(evt);
            }
        });
        midleft.add(buttonml);

        mid.setOpaque(false);
        mid.setLayout(new javax.swing.OverlayLayout(mid));

        movem.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        mid.add(movem);

        buttonm.setText("Mid");
        buttonm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                buttonmMousePressed(evt);
            }
        });
        mid.add(buttonm);

        midright.setOpaque(false);
        midright.setLayout(new javax.swing.OverlayLayout(midright));

        movemr.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        midright.add(movemr);

        buttonmr.setText("Mid Right");
        buttonmr.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                buttonmrMousePressed(evt);
            }
        });
        midright.add(buttonmr);

        botleft.setOpaque(false);
        botleft.setLayout(new javax.swing.OverlayLayout(botleft));

        movebl.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        botleft.add(movebl);

        buttonbl.setText("Bot Left");
        buttonbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                buttonblMousePressed(evt);
            }
        });
        botleft.add(buttonbl);

        botmid.setOpaque(false);
        botmid.setLayout(new javax.swing.OverlayLayout(botmid));

        movebm.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        botmid.add(movebm);

        buttonbm.setText("Bot Mid");
        buttonbm.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                buttonbmMousePressed(evt);
            }
        });
        botmid.add(buttonbm);

        botright1.setOpaque(false);
        botright1.setLayout(new javax.swing.OverlayLayout(botright1));

        movebr.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        botright1.add(movebr);

        buttonbr.setText("Bot Right");
        buttonbr.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                buttonbrMousePressed(evt);
            }
        });
        botright1.add(buttonbr);

        selections.setLayer(topleft, javax.swing.JLayeredPane.DEFAULT_LAYER);
        selections.setLayer(topm, javax.swing.JLayeredPane.DEFAULT_LAYER);
        selections.setLayer(topright, javax.swing.JLayeredPane.DEFAULT_LAYER);
        selections.setLayer(midleft, javax.swing.JLayeredPane.DEFAULT_LAYER);
        selections.setLayer(mid, javax.swing.JLayeredPane.DEFAULT_LAYER);
        selections.setLayer(midright, javax.swing.JLayeredPane.DEFAULT_LAYER);
        selections.setLayer(botleft, javax.swing.JLayeredPane.DEFAULT_LAYER);
        selections.setLayer(botmid, javax.swing.JLayeredPane.DEFAULT_LAYER);
        selections.setLayer(botright1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout selectionsLayout = new javax.swing.GroupLayout(selections);
        selections.setLayout(selectionsLayout);
        selectionsLayout.setHorizontalGroup(
            selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, selectionsLayout.createSequentialGroup()
                .addContainerGap(228, Short.MAX_VALUE)
                .addComponent(botright1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(75, 75, 75))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, selectionsLayout.createSequentialGroup()
                    .addContainerGap(22, Short.MAX_VALUE)
                    .addComponent(topleft, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(280, 280, 280)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(128, 128, 128)
                    .addComponent(topm, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(180, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(228, 228, 228)
                    .addComponent(topright, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(72, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(20, 20, 20)
                    .addComponent(midleft, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(278, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(133, 133, 133)
                    .addComponent(mid, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(178, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(226, 226, 226)
                    .addComponent(midright, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(70, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(17, 17, 17)
                    .addComponent(botleft, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(276, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(129, 129, 129)
                    .addComponent(botmid, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(178, Short.MAX_VALUE)))
        );
        selectionsLayout.setVerticalGroup(
            selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(selectionsLayout.createSequentialGroup()
                .addContainerGap(236, Short.MAX_VALUE)
                .addComponent(botright1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(26, 26, 26)
                    .addComponent(topleft, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(234, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(25, 25, 25)
                    .addComponent(topm, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(231, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(25, 25, 25)
                    .addComponent(topright, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(233, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(142, 142, 142)
                    .addComponent(midleft, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(139, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(138, 138, 138)
                    .addComponent(mid, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(137, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(142, 142, 142)
                    .addComponent(midright, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(140, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(235, 235, 235)
                    .addComponent(botleft, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(28, Short.MAX_VALUE)))
            .addGroup(selectionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(selectionsLayout.createSequentialGroup()
                    .addGap(237, 237, 237)
                    .addComponent(botmid, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(31, Short.MAX_VALUE)))
        );

        board1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tictactoe.png"))); // NOI18N

        gamefunctions.setLayer(selections, javax.swing.JLayeredPane.PALETTE_LAYER);
        gamefunctions.setLayer(board1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout gamefunctionsLayout = new javax.swing.GroupLayout(gamefunctions);
        gamefunctions.setLayout(gamefunctionsLayout);
        gamefunctionsLayout.setHorizontalGroup(
            gamefunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, gamefunctionsLayout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(selections, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
            .addGroup(gamefunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(gamefunctionsLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(board1, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(11, Short.MAX_VALUE)))
        );
        gamefunctionsLayout.setVerticalGroup(
            gamefunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gamefunctionsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(selections, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
            .addGroup(gamefunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(gamefunctionsLayout.createSequentialGroup()
                    .addComponent(board1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 13, Short.MAX_VALUE)))
        );

        instruct1.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        instruct1.setText("Welcome to TIC-TAC-TOE!");

        instruct2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        instruct2.setText("Try to get 3 in a row. Click any button to place your first move (Player X's Turn)!");

        resetButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        resetButton.setForeground(new java.awt.Color(153, 0, 0));
        resetButton.setText("Reset Game");
        resetButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                resetButtonMousePressed(evt);
            }
        });
        resetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetButtonActionPerformed(evt);
            }
        });

        modeButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        modeButton.setText("Switch Mode");
        modeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                modeButtonMousePressed(evt);
            }
        });

        game.setLayer(titlepanel, javax.swing.JLayeredPane.DEFAULT_LAYER);
        game.setLayer(gamefunctions, javax.swing.JLayeredPane.DEFAULT_LAYER);
        game.setLayer(jSeparator1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        game.setLayer(instruct1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        game.setLayer(instruct2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        game.setLayer(resetButton, javax.swing.JLayeredPane.DEFAULT_LAYER);
        game.setLayer(modeButton, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout gameLayout = new javax.swing.GroupLayout(game);
        game.setLayout(gameLayout);
        gameLayout.setHorizontalGroup(
            gameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gameLayout.createSequentialGroup()
                .addGroup(gameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(gameLayout.createSequentialGroup()
                        .addGap(188, 188, 188)
                        .addComponent(resetButton)
                        .addGap(28, 28, 28)
                        .addComponent(modeButton))
                    .addGroup(gameLayout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(instruct2)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, gameLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator1))
            .addGroup(gameLayout.createSequentialGroup()
                .addGroup(gameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(gameLayout.createSequentialGroup()
                        .addGap(226, 226, 226)
                        .addComponent(instruct1))
                    .addGroup(gameLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(titlepanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, gameLayout.createSequentialGroup()
                .addGap(0, 72, Short.MAX_VALUE)
                .addComponent(gamefunctions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 60, Short.MAX_VALUE))
        );
        gameLayout.setVerticalGroup(
            gameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(gameLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(titlepanel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(instruct1)
                .addGap(1, 1, 1)
                .addComponent(instruct2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(gameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modeButton, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(resetButton))
                .addGap(18, 18, 18)
                .addComponent(gamefunctions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getContentPane().add(game);

        menuTitle.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        menuTitle.setForeground(new java.awt.Color(153, 153, 255));
        menuTitle.setText("TIC-TAC-TOE");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel1.setText("Pick a Mode:");

        modeAI.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        modeAI.setText("1 Player");
        modeAI.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                modeAIMousePressed(evt);
            }
        });
        modeAI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modeAIActionPerformed(evt);
            }
        });

        mode2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        mode2.setText("2 Player");
        mode2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                mode2MousePressed(evt);
            }
        });

        menu.setLayer(menuTitle, javax.swing.JLayeredPane.DEFAULT_LAYER);
        menu.setLayer(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        menu.setLayer(modeAI, javax.swing.JLayeredPane.DEFAULT_LAYER);
        menu.setLayer(mode2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout menuLayout = new javax.swing.GroupLayout(menu);
        menu.setLayout(menuLayout);
        menuLayout.setHorizontalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLayout.createSequentialGroup()
                .addGap(164, 164, 164)
                .addGroup(menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(menuLayout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(menuLayout.createSequentialGroup()
                            .addComponent(modeAI)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(mode2))
                        .addComponent(menuTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(190, Short.MAX_VALUE))
        );
        menuLayout.setVerticalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLayout.createSequentialGroup()
                .addGap(154, 154, 154)
                .addComponent(menuTitle)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mode2)
                    .addComponent(modeAI))
                .addContainerGap(252, Short.MAX_VALUE))
        );

        getContentPane().add(menu);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttontlMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttontlMousePressed
        buttontl.setVisible(false);
        movetl.setText(getTurn());
        setTurn();
        anyWins();
        if (singlePlayer == true && aiMoves.size() > 2){
            aiMoves.remove(findIndex(0));
            playAI();
        }
    }//GEN-LAST:event_buttontlMousePressed

    private void buttontmMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttontmMousePressed
        buttontm.setVisible(false);
        movetm.setText(getTurn());
        setTurn();
        anyWins();
        if (singlePlayer == true && aiMoves.size() > 2){
            aiMoves.remove(findIndex(1));
            playAI();
        }
    }//GEN-LAST:event_buttontmMousePressed

    private void buttontrMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttontrMousePressed
        buttontr.setVisible(false);
        movetr.setText(getTurn());
        setTurn();
        anyWins();
        if (singlePlayer == true && aiMoves.size() > 2){
            aiMoves.remove(findIndex(2));
            playAI();
        }
    }//GEN-LAST:event_buttontrMousePressed

    private void buttonmlMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonmlMousePressed
        buttonml.setVisible(false);
        moveml.setText(getTurn());
        setTurn();
        anyWins();
        if (singlePlayer == true && aiMoves.size() > 2){
            aiMoves.remove(findIndex(3));
            playAI();
        }
    }//GEN-LAST:event_buttonmlMousePressed

    private void buttonmMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonmMousePressed
        buttonm.setVisible(false);
        movem.setText(getTurn());
        setTurn();
        anyWins();
        if (singlePlayer == true && aiMoves.size() > 2){
            aiMoves.remove(findIndex(4));
            playAI();
        }
    }//GEN-LAST:event_buttonmMousePressed

    private void buttonmrMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonmrMousePressed
        buttonmr.setVisible(false);
        movemr.setText(getTurn());
        setTurn();
        anyWins();
        if (singlePlayer == true && aiMoves.size() > 2){
            aiMoves.remove(findIndex(5));
            playAI();
        }
    }//GEN-LAST:event_buttonmrMousePressed

    private void buttonblMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonblMousePressed
        buttonbl.setVisible(false);
        movebl.setText(getTurn());
        setTurn();
        anyWins();
        if (singlePlayer == true && aiMoves.size() > 2){
            aiMoves.remove(findIndex(6));
            playAI();
        }
    }//GEN-LAST:event_buttonblMousePressed

    private void buttonbmMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonbmMousePressed
        buttonbm.setVisible(false);
        movebm.setText(getTurn());
        setTurn();
        anyWins();
        if (singlePlayer == true && aiMoves.size() > 2){
            aiMoves.remove(findIndex(7));
            playAI();
        }
    }//GEN-LAST:event_buttonbmMousePressed

    private void buttonbrMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonbrMousePressed
        buttonbr.setVisible(false);
        movebr.setText(getTurn());
        setTurn();
        anyWins();
        if (singlePlayer == true && aiMoves.size() > 2){
            aiMoves.remove(findIndex(8));
            playAI();
        }
    }//GEN-LAST:event_buttonbrMousePressed

    private void resetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_resetButtonActionPerformed

    private void resetButtonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_resetButtonMousePressed
        resetGame();
    }//GEN-LAST:event_resetButtonMousePressed

    private void modeButtonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_modeButtonMousePressed
        if (singlePlayer == false){
            singlePlayer = true;
            resetGame();
        }
        else {
            singlePlayer = false;
            resetGame();
        }
    }//GEN-LAST:event_modeButtonMousePressed

    private void modeAIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modeAIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_modeAIActionPerformed

    private void modeAIMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_modeAIMousePressed
        singlePlayer = true;
        game.setVisible(true);
        menu.setVisible(false);
    }//GEN-LAST:event_modeAIMousePressed

    private void mode2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mode2MousePressed
        singlePlayer = false;
        game.setVisible(true);
        menu.setVisible(false);
    }//GEN-LAST:event_mode2MousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FRMGameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FRMGameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FRMGameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FRMGameScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FRMGameScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel board1;
    private javax.swing.JPanel botleft;
    private javax.swing.JPanel botmid;
    private javax.swing.JPanel botright1;
    private javax.swing.JButton buttonbl;
    private javax.swing.JButton buttonbm;
    private javax.swing.JButton buttonbr;
    private javax.swing.JButton buttonm;
    private javax.swing.JButton buttonml;
    private javax.swing.JButton buttonmr;
    private javax.swing.JButton buttontl;
    private javax.swing.JButton buttontm;
    private javax.swing.JButton buttontr;
    private javax.swing.JLayeredPane game;
    private javax.swing.JLayeredPane gamefunctions;
    private javax.swing.JLabel instruct1;
    private javax.swing.JLabel instruct2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLayeredPane menu;
    private javax.swing.JLabel menuTitle;
    private javax.swing.JPanel mid;
    private javax.swing.JPanel midleft;
    private javax.swing.JPanel midright;
    private javax.swing.JButton mode2;
    private javax.swing.JButton modeAI;
    private javax.swing.JButton modeButton;
    private javax.swing.JLabel movebl;
    private javax.swing.JLabel movebm;
    private javax.swing.JLabel movebr;
    private javax.swing.JLabel movem;
    private javax.swing.JLabel moveml;
    private javax.swing.JLabel movemr;
    private javax.swing.JLabel movetl;
    private javax.swing.JLabel movetm;
    private javax.swing.JLabel movetr;
    private javax.swing.JButton resetButton;
    private javax.swing.JLayeredPane selections;
    private javax.swing.JLabel title;
    private javax.swing.JPanel titlepanel;
    private javax.swing.JPanel topleft;
    private javax.swing.JPanel topm;
    private javax.swing.JPanel topright;
    // End of variables declaration//GEN-END:variables
}
